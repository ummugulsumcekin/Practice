//
//  ViewController.swift
//  hepsiburadauygulama
//
//  Created by Ummugulsum Çekin on 26.04.2022.
//

import UIKit

class ViewController: UIViewController {


    
    @IBOutlet weak var kategoriCollectionView: UICollectionView!
    var kategoriListesi = [Kategoriler]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
      
        
        kategoriCollectionView.delegate = self
        kategoriCollectionView.dataSource = self
        
        let u1 = Kategoriler(kategoriId: 1, kategoriResim: "gıda ve içeçek")
        let u2 = Kategoriler(kategoriId: 2, kategoriResim: "annelergunu")
        let u3 = Kategoriler(kategoriId: 3, kategoriResim: "addax")
        
        
        kategoriListesi.append(u1)
        kategoriListesi.append(u2)
        kategoriListesi.append(u3)
       
        
       
        let tasarim = UICollectionViewFlowLayout()
        //çevre boşluk
        tasarim.sectionInset = UIEdgeInsets(top: 0, left: 5, bottom: 5, right: 5)
        //YATAY itemlar arası BOSLUK
        tasarim.minimumInteritemSpacing = 5
        //Dikey itemlar arası BOSLUK
        tasarim.minimumLineSpacing = 2
        //collectıon genişlik
        let genislik = kategoriCollectionView.frame.size.width
        //hücre genişlik
        let hucreGenislik = (genislik - 10) / 1
        tasarim.itemSize = CGSize(width: hucreGenislik, height: hucreGenislik/2)
        kategoriCollectionView.collectionViewLayout = tasarim
    }

}

extension ViewController : UICollectionViewDelegate,UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return kategoriListesi.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let kategori = kategoriListesi[indexPath.row]
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "kategorihucre", for: indexPath) as! kategorihucreCollectionViewCell
     
        
        cell.tanitimpicture.image = UIImage(named: "\(kategori.kategoriResim!)")
        
        return cell
    }
}
