//
//  kategorihucreCollectionViewCell.swift
//  hepsiburadauygulama
//
//  Created by Ummugulsum Çekin on 2.05.2022.
//

import UIKit

class kategorihucreCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var tanitimpicture: UIImageView!
    


}
