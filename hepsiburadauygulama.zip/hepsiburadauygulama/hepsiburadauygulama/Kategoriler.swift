//
//  kategoriler.swift
//  hepsiburadauygulama
//
//  Created by Ummugulsum Çekin on 1.05.2022.
//

import Foundation
class Kategoriler {
    var kategoriId:Int?
    var kategoriResim:String?
    
    init(kategoriId:Int,kategoriResim:String){
       
        self.kategoriId = kategoriId
        self.kategoriResim = kategoriResim
    }
}
