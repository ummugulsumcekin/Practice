import UIKit

//islem
var islemNo = 8937
var ogrNo = 2874819
var kitapNo = 565
let aTarih = "2021-07-11"
let vTarih : String = "2021-08-12"


print(islemNo)
print(ogrNo)
print(kitapNo)
print(aTarih)
print(vTarih)

var ogAd : String = "Erhan"
var ogrSoyad : String = "Kaya"
var cinsiyet = "Erkek"
var dTarih = "2021-09-12"
var sınıf : String = "G101"

print("-------")
print(ogAd, ogrSoyad)
print(cinsiyet)
print(dTarih)
print(sınıf)

var isbnNo = "US2345678FB"
var kitapAdı = "Empati"
var yazarNo : String = "Pegasus488"
var turNo = 404
var sayfaSayısı : Int = 789
var puan = 10

print(isbnNo)
print(kitapAdı)
print(yazarNo)
print(turNo)
print(sayfaSayısı)
print(puan)

print("-------")

var yazarAd = "Adam"
var yazarSoyad = "Fawer"
var turAdı = "Kurgu ve Gerilim"

print(yazarAd)
print(yazarSoyad)
print(turAdı)
