import UIKit

class Ödev2 {
    
    func dereceDönüstürücü (derece :Float)-> Float {
        return (derece*1.8) + 32
    }
    
    func diktörtgenÇevrehesabı (x: Int, y:Int)-> Int {
        return (x+y)*2
    }
    
    func faktoriyelHesabı (z:Int)-> Int {
        var result = 1
        if(z > 0) {
            for i in 1...z {
                result = result*i //result *=i
            }
        }
     return result
    }
    func harfSayısıBulmaca ( kelime :String, harf :Character)-> Int {
        let letters = Array(kelime);
        var count = 0
        for letter in letters {
            if letter == harf {
               count += 1
            }
        }
    return count
    }
    func interiors (edge1 : Int, edge2 : Double, edge3 : Int, edge4 : Int, edge5 : Int) -> Int
        {
             
            let n = 5
            let sum = (n-2)*180 //let sum = 3 * 180
            
            return sum
        }
    func salaryTotal (dailyPrice:Int,dayCount:Int,extraHour:Int) {
        
        if extraHour > 0 {
            let salaryTotal = (8 * 10) * dayCount + (extraHour * 20)
            print(salaryTotal)
        }else{
            let salaryTotal = (8 * 10) * dayCount
            print("normalSalary : \(salaryTotal)")
        }
        
    }
    func kotaHesabi (monthly: Int, kotaAsim: Int) -> Int {
        let kotaHesabi :Int
        if kotaAsim > 0 {
            kotaHesabi = (monthly + (kotaAsim * 4) )
            
        }else{
                
        kotaHesabi = monthly
            
    }
    
        return kotaHesabi
    }
}
        
// practice

let x = Ödev2 ()

print("Fahrenhite:  \(x.dereceDönüstürücü (derece: 26))")

print("Çevre Hesabı: \(x.diktörtgenÇevrehesabı(x: 20,y: 45))")

print("Faktoriyel Sonucu: \(x.faktoriyelHesabı(z: 5))")

print("Kelimedeki Toplan Harf Sayısı: \(x.harfSayısıBulmaca(kelime: "ummugulsum", harf: "u"))")

print("Kenar Toplamı: \(x.interiors(edge1: 7, edge2: 12.5, edge3: 9, edge4: 8,  edge5: 7))")

print("Maas Hesabı: \(x.salaryTotal(dailyPrice: 80, dayCount: 15, extraHour: 6))")

print("Kota Hesabı: \(x.kotaHesabi(monthly: 100, kotaAsim: 5))")
